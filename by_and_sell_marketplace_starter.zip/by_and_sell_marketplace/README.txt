by&sell Marketplace — Starter Demo
==================================
এটি একটি প্রাথমিক PWA/ওয়েব অ্যাপ ডেমো; এটি এখনো Play Store-এ প্রকাশযোগ্য Android AAB নয়।

যা কাজ করে:
- পণ্য তালিকা, ক্যাটাগরি ও সার্চ
- পণ্য পোস্টের ফর্ম
- এই ডিভাইসের ব্রাউজারে নিজের পোস্ট সংরক্ষণ (localStorage)
- Chrome থেকে হোম স্ক্রিনে যোগ করার জন্য manifest/service worker

যা এখনো নেই:
- বাস্তব লগইন/অ্যাকাউন্ট
- সার্ভার/অনলাইন ডেটাবেস; অন্য ব্যবহারকারীর পোস্ট দেখা যায় না
- প্রকৃত ছবি আপলোড, চ্যাট, অর্ডার, পেমেন্ট
- রিপোর্ট/মডারেশন, নীতিমালা ও গোপনীয়তা নীতি
- Android AAB build ও পরীক্ষা

ফোন থেকে পরীক্ষা:
1. GitHub-এ নতুন public repository বানান, নাম: by-and-sell.
2. Add file > Create new file ব্যবহার করে index.html, manifest.json, sw.js আলাদা করে তৈরি করুন; এই ZIP-এর ফাইলের বিষয়বস্তু কপি করুন।
3. Settings > Pages > Deploy from a branch > main > /(root) > Save.
4. প্রকাশিত HTTPS ঠিকানা Chrome-এ খুলুন; Chrome menu থেকে Install app বা Add to Home screen দিন.

Play Store-এ প্রকাশের আগে:
- আসল ব্যাকএন্ড ও নিরাপদ লগইন/ডেটাবেস যোগ করতে হবে।
- গোপনীয়তা নীতি, Data safety, content rating, store listing ও screenshots প্রস্তুত করতে হবে।
- Android project থেকে release-signed Android App Bundle (.aab) বানাতে হবে; এই HTML ফাইল সরাসরি Play Console-এ আপলোড করা যাবে না।
- Play Console-এর বর্তমান নিয়ম ও testing requirements পূরণ করে review-তে পাঠাতে হবে।
- নতুন অ্যাপের জন্য 31 Aug 2026 থেকে target Android 16 (API 36)+ আবশ্যক—প্রকাশের দিন নিয়ম আবার যাচাই করুন।

গুরুত্বপূর্ণ: ডেমোতে আসল ফোন নম্বর দেবেন না। বাস্তব ব্যবহারকারীর তথ্য সংগ্রহের আগে নিরাপত্তা ও গোপনীয়তা ব্যবস্থা তৈরি করুন।
